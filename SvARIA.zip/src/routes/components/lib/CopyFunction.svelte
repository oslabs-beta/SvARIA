<button
	on:click
	id="clipBoardButton"
	class="float-right rounded-md bg-transparent text-sm text-black dark:text-white"
	type="button"
>
	<svg fill="none" viewBox="0 0 25 25" stroke="currentColor" stroke-width="1.5" class="h-7 w-7">
		<path
			stroke-linecap="round"
			stroke-linejoin="round"
			d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
		>
		</path>
	</svg>
</button>
