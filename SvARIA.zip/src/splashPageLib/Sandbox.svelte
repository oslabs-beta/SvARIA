<script lang='ts'>
	export let title: string = '';
	export let source: string = '';
</script>

<iframe
	title={title}
	src={source}
	width="900px"
	height="600px"
></iframe> 