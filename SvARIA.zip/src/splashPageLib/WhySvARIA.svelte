<!-- This is where the General Product Description lives -->
<script>
    import SectionWrapper from "./SectionWrapper.svelte";

</script>
<br><br><br><br>
<SectionWrapper id="WhySvARIA">
    <div class="flex flex-col gap-5 sm:gap-10 md:gap-15 flex-1 items-center justify-center pb-10 md:pb-14">
        <div class="flex flex-col gap-2">
      
            <h2 class="text-4xl sm:text-5xl md:text-6xl max-w-[1000px] mx-auto w-full font-semibold text-center">
                Svelte + ARIA = SvARIA
            </h2>
        </div>
            <h3 class="text-2xl sm:text-3xl md:text-4xl max-w-[1000px] mx-auto w-full  text-center">
                A comprehensive component library built from the ground-up for Svelte offering plug-and-play
                ARIA compliant components + features to help your project meet and exceed accessibility standards
                while streamlining the design process.
            </h3> 
    </div>
</SectionWrapper>