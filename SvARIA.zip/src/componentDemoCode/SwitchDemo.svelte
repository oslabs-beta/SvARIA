<script>
    import { Switch}  from 'svaria-toolkit'
</script>

<Switch
    defValue="JS"
    altValue="TS"
    className='s s--inner'
    style=''
    ariaDefValue="Typescript"
    ariaAltValue="Javascript"
/>