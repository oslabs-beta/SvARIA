<script>
	import { Toast } from 'svaria-toolkit';
</script>

<Toast
	toastClass="left-0 flex items-center w-full max-w-xs p-4 text-white bg-gray-800 rounded-lg shadow dark:text-gray-500 dark:bg-white"
	message="add a custom toast message"
	messageClass="ms-3 text-sm font-normal"
	toastId="toastId"
	toastContainerId="toastPosition"
	containerClass="absolute top-0"
	autoShutDown="5000"
/>
