import { defineConfig } from 'svelte-check';

export default defineConfig({
  typescript: {
    tsconfigFile: './tsconfig.json',
  },
  
});