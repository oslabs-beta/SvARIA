export type ErrObj = {
    err: string
}